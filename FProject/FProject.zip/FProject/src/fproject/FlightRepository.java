package fproject;

import java.util.List;

public class FlightRepository 
{
   List<MainFlight> listFlights;
    
    public void addFlight()
    {
        
    }
    
    public void removeFlight()
    {
        
    }
    
    public void listFlights()
    {
        
    } 
}
