package fproject;

enum FlightSegmentReservationEnum 
{
     BUSINESS, ECONOMIC
}
