package fproject;

public class Passenger extends MainFlight
{
    String Identity;
    
    public void bookFlight()
    {
        
    }
    
    public void cancelFlight()
    {
        
    }
    
    public void makePayment()
    {
        
    }
}
