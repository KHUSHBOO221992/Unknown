package fproject;

public interface DepartingDate 
{
    public String g_date = "",g_time = "";
    
    public String get_date();
  
    public String get_time();
}
