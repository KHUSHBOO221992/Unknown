package fproject;

public abstract class PassengerList 
{
    int[] listOfPassengers;
    
    public void add()
    {
        
    }
    
    public void remove()
    {
        
    }
}
