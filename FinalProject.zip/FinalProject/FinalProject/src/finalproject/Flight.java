package finalproject;

import java.util.HashMap;
import java.util.Map;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.*;

/**
 * Show the passenger list of the flightrepository
 * @author Khushboo
 */

public class Flight extends PassengerList //Itinerary
{
    static Connection conn;
    static PreparedStatement stmt;
    static ResultSet rs = null;
    static String USER = "root";
    static String PASS = "";
    
    static void connectDB()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/KhushFinalProject", USER, PASS);
            
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    Itinerary itinerary;
    DepartureDate departureDate;

    String number;
    String pilotName;

    boolean isAvailable = true;

    Map<Seat, Integer> passengerList = new HashMap<Seat, Integer>();
/**
 * Flight inherits from passenger list
 * @param itinerary
 * @param departureDate
 * @param number
 * @param pilotName 
 */
    Flight(Itinerary itinerary, DepartureDate departureDate, String number, String pilotName) 
    {
        this.itinerary = itinerary;
        this.departureDate = departureDate;
        this.number = number;
        this.pilotName = pilotName;
        initializeSeats();
    }
/**
     * Set the passenger seat according to the passenger ID
     * @param passengerID
     * @return 
     */
    @Override
    public int setPassengerSeat(Integer passengerID) 
    {
        Integer seatReserved = 0;
        for (Map.Entry<Seat, Integer> entry : this.passengerList.entrySet()) 
        {
            if (entry.getValue() == 0) 
            {
                entry.setValue(passengerID);
                seatReserved = entry.getKey().Number;
                System.out.println("Seat number: " + seatReserved + " for the passengerID: " + passengerID);
                break;
            }
        }
        verifyFlighAvailable();

        return seatReserved;
    }
/**
     * Remove a seat of a certain passenger
     * @param passengerID
     * @return 
     */
    @Override
    public int removePassengerSeat(Integer passengerID) 
    {
        Integer seatReserved = 0;
        for (Map.Entry<Seat, Integer> entry : this.passengerList.entrySet()) 
        {
            if (entry.getValue() == passengerID) 
            {
                Seat objSeat = new Seat();
                objSeat.Number = 0;
                entry.setValue(objSeat.Number);
                seatReserved = entry.getKey().Number;
                System.out.println("Seat removed: " + seatReserved);
            }
        }
        verifyFlighAvailable();

        return seatReserved;
    }
/**
     * Show if the seats is reserved or not
     */
    public void showSeatsStatus() 
    {

        System.out.println("Flight number: " + this.number);
        for (Map.Entry<Seat, Integer> entry : this.passengerList.entrySet()) 
        {
            System.out.println("Seat: " + entry.getKey().Number + " Reserved for the passenger [" + entry.getValue() + "]");
        }
        
        System.out.println("");
    }

    public void verifyFlighAvailable() 
    {
        this.isAvailable = false;
        for (Integer value : this.passengerList.values()) 
        {
            if (value == 0) 
            {
                this.isAvailable = true;
            }
        }
    }
/**
     * set all the seats to not reserved
     */
    private void initializeSeats() 
    {
        int count;
        for (count = 1; count < 11; count++) 
        {
            Seat objSeat = new Seat();
            objSeat.Number = count;
            passengerList.put(objSeat, 0);
        }
    }
 /**
     * Get the itinerary
     */
    public void getItinerary() 
    {
        System.out.println("Itinerary info: ");
        System.out.println("Start point: " + itinerary.startPoint);
        System.out.println("End point: " + itinerary.endPoint);
    }

    //gets and setters
    /**
     * Get the number flight
     * @return 
     */
    
    public String getNumber() 
    {
        return this.number;
    }
/**
     * Set the number flight
     * @param name 
     */
    public void setNumber(String name) 
    {
        this.number = number;
    }
/**
     * @return Return the pilotname
     */
    public String getPilotName() 
    {
        return this.pilotName;
    }
/**
     * Set the pilot name
     * @param pilotName 
     */
    public void setPilotName(String pilotName) 
    {
        this.pilotName = pilotName;
    }
//    static void addFlightDB(String FlightNumber,String Departure,String Arrival,String DepartureDate,
//    String DepartureTime,String PilotName){
//        try{
//            stmt = conn.prepareStatement("INSERT INTO Flight VALUES(?,?,?,?,?,?)");
//            stmt.setString(1, FlightNumber);
//            stmt.setString(2, Departure);
//            stmt.setString(3, Arrival);
//            stmt.setString(4,DepartureDate );
//            stmt.setString(5,DepartureTime );
//            stmt.setString(6,PilotName );
//            
//            
//            int nrec = stmt.executeUpdate();
//            System.out.println(nrec + "Flight has been Inserted");
//           
//        }
//        catch(SQLException e){
//            e.printStackTrace();
//        }
//    }
//     static void removeFlightDB(String FlightNumber){
//        try{
//            stmt = conn.prepareStatement("DELETE FROM Flight WHERE flightNumber = ?");
//            stmt.setString(1, FlightNumber);
//            
//            int nrec = stmt.executeUpdate();
//            System.out.println(nrec + " Flight has been Removed from Record");
//           
//        }
//        catch(SQLException e){
//            e.printStackTrace();
//        }
//    }
//     static void updateFlightDB(String Departure,String Arrival,String DepartureDate,
//    String DepartureTime,String PilotName,String FlightNumber){
//        try{
//            stmt = conn.prepareStatement("UPDATE Person SET  departureLocation = ?,"
//                    + " arrivalLocation = ?,departureDate = ?,departureTime = ?,pilotName = ? WHERE flightNumber = ?");
//            
//            stmt.setString(1,Departure);
//            stmt.setString(2, Arrival);
//            stmt.setString(3, DepartureDate);
//            stmt.setString(4, DepartureTime);
//            stmt.setString(5, PilotName);
//            stmt.setString(6, FlightNumber);
//            
//            
//            int nrec = stmt.executeUpdate();
//            System.out.println(nrec + " Flight Record Updated");
//           
//        }
//        catch(SQLException e){
//            e.printStackTrace();
//        }        
//    }
//     static void listFlightDB(){
//        try{
//            stmt = conn.prepareStatement("SELECT * FROM Flight");
//            
//            
//            
//           rs = stmt.executeQuery();
//           
//           while(rs.next()){
//              
//               System.out.println(" Flight Number : " + rs.getString("flightNumber") + 
//                       "\n Departure Location : " + rs.getString("departureLocation") + 
//                       "\n Arrival Location : " + rs.getString("arrivalLocation") + 
//                       "\n Departure Date : " + rs.getString("departureDate")+
//                       "\n Departure Time : " + rs.getString("departureTime")+
//                       "\n Pilot Name : " + rs.getString("pilotName"));
//           }
//           
//        }
//        catch(SQLException e){
//            e.printStackTrace();
//        }
//    }
//    static void selectFlightDB(String departure,String arrival){
//        try{
//            stmt = conn.prepareStatement("SELECT * FROM Flight where departureLocation = ? and arrivalLocation = ?");
//            stmt.setString(1,departure);
//            stmt.setString(2,arrival);
//            
//            
//           rs = stmt.executeQuery();
//           
//           while(rs.next()){
//              
//               System.out.println(" Flight Number : " + rs.getString("flightNumber") + 
//                       "\n Departure Location : " + rs.getString("departureLocation") + 
//                       "\n Arrival Location : " + rs.getString("arrivalLocation") + 
//                       "\n Departure Date : " + rs.getString("departureDate")+
//                       "\n Departure Time : " + rs.getString("departureTime")+
//                       "\n Pilot Name : " + rs.getString("pilotName"));
//           }
//           
//        }
//        catch(SQLException e){
//            e.printStackTrace();
//        }
//    }

}
