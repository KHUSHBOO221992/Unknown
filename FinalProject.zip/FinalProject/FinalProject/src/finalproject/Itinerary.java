package finalproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * the place of flight
 * @author Khushboo
 */

public class Itinerary
{
    String startPoint;
    String endPoint;
    static Connection conn;
    static PreparedStatement stmt;
    static ResultSet rs = null;
    static String USER = "root";
    static String PASS = "";
    
    static void connectDB()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/KhushFinalProject", USER, PASS);
            
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    Itinerary(String startPoint, String endPoint)
    {
        this.startPoint = startPoint;
        this.endPoint = endPoint;
    }
    //get and setters
    /**
     * get the startpoint, such as Brazil
     * @return 
     */
    
   public String getStartPoint()
   {
       return this.startPoint;
   } 
   /**
    * set the startpoint
    * @param startPoint 
    */
   public void setStartPoint(String startPoint)
   {
       this.startPoint = startPoint;
   } 
   /**
    * return the end point
    * @return 
    */
     public String getEndPoint()
     {
       return this.endPoint;
   } 
   /**
      * set the end point
      * @param endPoint 
      */
   public void setEndPoint(String endPoint)
   {
       this.endPoint = endPoint;
   }
}
