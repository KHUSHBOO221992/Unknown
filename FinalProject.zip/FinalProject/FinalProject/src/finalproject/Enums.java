package finalproject;
/**
 * user can choose business or economic
 * @author Khushboo
 */
enum FlightSegmentReservationEnum 
{
   BUSINESS, ECONOMIC
}