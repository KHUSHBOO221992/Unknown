package finalproject;

import java.util.List;
/*
 * Business : Bigger Seats and Extra Facilities
 * Economic : Regular facilities
 */
/**
 * Ticket is Valid Only when the passenger done with the payment
 * @author Khushboo
 */

public class Ticket extends Passenger implements IFlightSegmentReservation 
{

    String segmentSelected;

    Ticket(String SegmentSelected, Integer PassengerID, String Identity, Itinerary itinerary, DepartureDate departureDate, String number, String pilotName) {
        super(PassengerID, Identity, itinerary, departureDate, number, pilotName);
        this.segmentSelected = SegmentSelected;
    }
/**
     * computing price uses the fares, number of seats and the type of reservation
     * @param lstSeatsReservedByPassenger 
     */
    @Override
    public void computePrice(List<Integer> lstSeatsReservedByPassenger) 
    {
        List<Fare> lstFares = FlightRepository.returnFares(number);
        double totalFaresAmount = 0;
        for (Fare item : lstFares) 
        {
            totalFaresAmount = totalFaresAmount + item.price;
        }

        Integer numberOfReservedSeats = lstSeatsReservedByPassenger.size();
        double totalAmount = totalFaresAmount;

        if (this.segmentSelected == FlightSegmentReservationEnum.BUSINESS.toString()) 
        {
            totalAmount = totalAmount + (numberOfReservedSeats * 8);
        } else 
        {
            totalAmount = totalAmount + (numberOfReservedSeats * 2);
        }

        System.out.println("Payemnt details: ");
        System.out.println("Total fares amount: " + totalFaresAmount);
        System.out.println("Number of reserved seats: " + numberOfReservedSeats);
        System.out.println("Type of segment: " + this.segmentSelected);
        System.out.println("Overall Total amount: " + totalAmount);
    }

}
