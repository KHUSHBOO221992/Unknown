package finalproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
//import java.sql.*;
/*
@author Khushboo

**
 * a passenger needs to be related to a flight, otherwise it will not be a passenger
 * PassengerID needs to be unique
 */
public class Passenger extends Flight
{
    Integer PassengerID;
    String Identity;
    /**
     * calling the flight super, because extends the flight class
     * @param PassengerID
     * @param Identity
     * @param itinerary
     * @param departureDate
     * @param number
     * @param pilotName 
     */
    
    
    static Connection conn;
    static PreparedStatement stmt;
    static ResultSet rs = null;
    static String USER = "root";
    static String PASS = "";
    String name;
    String email;
    int contact;
    String streetNumber;
    String city;
    String flightNumber;
    String paymentMethod;
    Scanner input = new Scanner(System.in);
    static void connectDB(){
    try{
    
    Class.forName("com.mysql.jdbc.Driver");
    conn = DriverManager.getConnection("jdbc:mysql://localhost/KhushFinalProject", USER, PASS);
    
    }catch(Exception e){
    e.printStackTrace();
    }
    }
    
    void addFlightDB(String flightNumber){
    try{
    stmt = conn.prepareStatement("INSERT INTO Passenger VALUES(?,?,?,?,?,?,?)");
    stmt.setString(1, this.name);
    stmt.setString(2, this.email);
    stmt.setInt(3, this.contact);
    stmt.setString(4,this.streetNumber );
    stmt.setString(5,this.city );
    stmt.setString(6,flightNumber );
    stmt.setString(7, this.paymentMethod);
    
    
    int nrec = stmt.executeUpdate();
    System.out.println(nrec + "Flight Has Been Booked");
    
    }
    catch(SQLException e){
    e.printStackTrace();
    }
    }
    static void removeFlightDB(String FlightNumber){
    try{
    stmt = conn.prepareStatement("DELETE FROM Passenger WHERE flightNumber = ?");
    stmt.setString(1, FlightNumber);
    
    int nrec = stmt.executeUpdate();
    System.out.println(nrec + " Flight has been Cancelled ");
    
    }
    catch(SQLException e){
    e.printStackTrace();
    }
    }
    void paymentMethod(){
    System.out.println("Enter Payment Method : ");
    this.paymentMethod = input.nextLine();
            System.out.println("Enter Card Number: ");
            int card = input.nextInt();
    }
    void readData(){
    System.out.println("Name : ");
    this.name = input.nextLine();
    System.out.println("Email : ");
    this.email = input.nextLine();
    System.out.println("Contact Number : ");
    this.contact = input.nextInt();
    System.out.println("Street Number : ");
    this.streetNumber = input.nextLine();
    System.out.println("City : ");
    this.city = input.nextLine();
    
    }
    static void listFlightDB(){
    try{
    stmt = conn.prepareStatement("SELECT * FROM Passenger");
    
    
    
    rs = stmt.executeQuery();
    
    while(rs.next()){
    
    System.out.println(" Name : " + rs.getString("name") +
    "\n Email : " + rs.getString("email") +
    "\n Contact Number : " + rs.getString("contactNumber") +
    "\n Street Address : " + rs.getString("streetNumber")+
    "\n City : " + rs.getString("city")+
    "\n Flight Number : " + rs.getString("flightNumber")+
    "\n Payment Method : " + rs.getString("paymentMethod"));
    }
    
    }
    catch(SQLException e){
    e.printStackTrace();
    }
    }

    public Passenger(Integer PassengerID, String Identity, Itinerary itinerary, DepartureDate departureDate, String number, String pilotName) {
       super(itinerary, departureDate, number, pilotName);
       this.Identity = Identity;
       this.PassengerID = PassengerID;
    }
    
    /**
     * Book a flight for this passenger
     */
    
    public void bookFlight()
    {
        Flight flightObject = FlightRepository.getFlight(this.number);
        if (flightObject == null)
        {
            System.out.println("Please select a valid flight number");
        }
        flightObject.setPassengerSeat(this.PassengerID);
    }
    /**
     * Canclation of Flight
     */
    public void cancelFlight()
    {
        
        Flight flightObject = FlightRepository.getFlight(this.number);
        if (flightObject == null)
        {
            System.out.println("Please select a valid flight number");
        }
        flightObject.removePassengerSeat(this.PassengerID);
    }
    /**
     * Make the payment
     */
    public void makePayment()
    {
        FlightRepository.availableFlights();
        Scanner input = new Scanner(System.in);
        System.out.println("Select the type of your ticket");
        System.out.println("1 for Business and 2 for Economic");
        Integer flightReservation = input.nextInt();
        
        Ticket objTicket;
        
        if(flightReservation == 1)
        {
        objTicket = new Ticket(FlightSegmentReservationEnum.BUSINESS.toString(), this.PassengerID, this.Identity, itinerary, departureDate, number, pilotName);
        }
        else
        {
        objTicket = new Ticket(FlightSegmentReservationEnum.ECONOMIC.toString(), this.PassengerID, this.Identity, itinerary, departureDate, number, pilotName);
        }
        
        List<Integer> lstInteger = FlightRepository.SeatsInAFlightReservedByAPassenger(this.number, this.PassengerID);
        
        objTicket.computePrice(lstInteger);
        
        System.out.println("Ticket paid");
    }
}
