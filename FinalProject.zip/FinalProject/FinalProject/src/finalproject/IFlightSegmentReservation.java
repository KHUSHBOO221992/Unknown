package finalproject;

import java.util.List;
//import java.sql.*;
//import java.util.Scanner;

/**
 * the interface that has the computing price and the enums of segmentreservationtypes
 * @author Khushboo
 */

interface IFlightSegmentReservation
{
    
    String[] FlightSegmentReservationTypes = {FlightSegmentReservationEnum.BUSINESS.toString(),FlightSegmentReservationEnum.ECONOMIC.toString() };
    
     void computePrice(List<Integer> lstSeatsReservedByPassenger);
}

//public class IFlightSegmentReservation {
//    static Connection conn;
//    static PreparedStatement stmt;
//    static ResultSet rs = null;
//    static String USER = "root";
//    static String PASS = "";
//    String flightNumber;
//    String flightType;
//    String route;
//    float tax;
//    int price;
//    float totalPrice;
//    Scanner input = new Scanner(System.in);
//    static void connectDB(){
//        try{
//            
//            Class.forName("com.mysql.jdbc.Driver");
//            conn = DriverManager.getConnection("jdbc:mysql://localhost/KhushFinalProject", USER, PASS);
//            
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//    }
//    void getData(){
//        System.out.println("Enter Flight Type (Economic or Business)");
//        this.flightType = input.nextLine();
//        System.out.println("Enter Route (oneway or return)");
//        this.route = input.nextLine();
//    }
//    void computePrice(String flightNumber){
//         try{
//            stmt = conn.prepareStatement("SELECT * FROM Fare where flightNumber = ? and flightType = ? and  route = ?");
//            
//            stmt.setString(1, flightNumber);
//            stmt.setString(2, this.flightType);
//            stmt.setString(3, this.route);
//            
//           rs = stmt.executeQuery();
//           while(rs.next()){
//           this.tax = rs.getFloat("tax");
//           this.price = rs.getInt("price");
//           }
//           this.totalPrice = this.price + this.tax;
//          
//           
//        }
//        catch(SQLException e){
//            e.printStackTrace();
//        }
//    }
//    
//     void addFlightDB(String flightNumber){
//        try{
//            stmt = conn.prepareStatement("INSERT INTO FlightSegmentReservation VALUES(?,?,?,?,?,?)");
//            stmt.setString(1,flightNumber );
//            stmt.setString(2, this.flightType);
//            stmt.setString(3, this.route);
//            stmt.setInt(4, this.price );
//            stmt.setFloat(5,this.tax );
//            stmt.setFloat(6,this.totalPrice );
//            
//            
//            int nrec = stmt.executeUpdate();
//            System.out.println(nrec + " Record has been Inserted");
//           
//        }
//        catch(SQLException e){
//            e.printStackTrace();
//        }
//    }
//    static void join1(){
//        
//    } 
//    
//}
