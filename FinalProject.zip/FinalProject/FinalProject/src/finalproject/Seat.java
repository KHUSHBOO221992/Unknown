package finalproject;

/**
 * seats will be the key of the dictionary in flight class
 * @author Khushboo
 */
public class Seat 
{
   int Number;
}
