-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2018 at 05:30 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `khushfinalproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `fare`
--

CREATE TABLE `fare` (
  `flightNumber` varchar(10) NOT NULL,
  `flightType` varchar(20) NOT NULL,
  `route` varchar(20) NOT NULL,
  `tax` float NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fare`
--

INSERT INTO `fare` (`flightNumber`, `flightType`, `route`, `tax`, `price`) VALUES
('XXX', 'economic', 'oneway', 23.1, 45000),
('XXX', 'business', 'oneway', 30.4, 99000);

-- --------------------------------------------------------

--
-- Table structure for table `flight`
--

CREATE TABLE `flight` (
  `flightNumber` varchar(10) NOT NULL,
  `departureLocation` varchar(20) NOT NULL,
  `arrivalLocation` varchar(20) NOT NULL,
  `departureDate` varchar(10) NOT NULL,
  `departureTime` varchar(8) NOT NULL,
  `pilotName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flight`
--

INSERT INTO `flight` (`flightNumber`, `departureLocation`, `arrivalLocation`, `departureDate`, `departureTime`, `pilotName`) VALUES
('XXY', 'India', 'Canada', '2018-04-03', '03:11:00', 'Jorden'),
('XYY', 'Canada', 'India', '2018-04-04', '13:20:00', 'Alex'),
('XXX', 'India', 'Australia', '2018-04-04', '22:34:00', 'Rohan');

-- --------------------------------------------------------

--
-- Table structure for table `flightsegmentreservation`
--

CREATE TABLE `flightsegmentreservation` (
  `flightNumber` varchar(10) NOT NULL,
  `flightType` varchar(20) NOT NULL,
  `route` varchar(20) NOT NULL,
  `price` int(10) NOT NULL,
  `tax` float NOT NULL,
  `totalPrice` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flightsegmentreservation`
--

INSERT INTO `flightsegmentreservation` (`flightNumber`, `flightType`, `route`, `price`, `tax`, `totalPrice`) VALUES
('XXX', 'economic', 'oneway', 45000, 23.1, 23.145),
('XXX', 'economic', 'oneway', 45000, 23.1, 45023.1),
('xxx', 'business', 'return', 0, 0, 0),
('M3A3A7', 'BUSINESS', 'ONEWAY', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `itinerary`
--

CREATE TABLE `itinerary` (
  `StartPoint` text NOT NULL,
  `EndPoint` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `contactNumber` int(11) NOT NULL,
  `streetNumber` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `flightNumber` varchar(10) NOT NULL,
  `paymentMethod` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`name`, `email`, `contactNumber`, `streetNumber`, `city`, `flightNumber`, `paymentMethod`) VALUES
('kamal', 'kamal', 23344, '', 'brampton', 'xxy', 'creditcard'),
('khushboo', 'kb@gmail.com', 1234561234, '100', 'toronto', 'xxx', 'visa'),
('Nithin', 'nkc@yahoo.ca', 2134561234, '150', 'Toronto', 'XYY', 'master card');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
