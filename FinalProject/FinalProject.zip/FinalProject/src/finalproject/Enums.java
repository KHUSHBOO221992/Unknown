package finalproject;

enum FlightSegmentReservationEnum 
{
   BUSINESS, ECONOMIC
}