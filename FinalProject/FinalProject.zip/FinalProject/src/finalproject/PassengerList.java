package finalproject;

public abstract class PassengerList 
{
    int[] listOfPassengers;
    
   
   public abstract int setPassengerSeat(Integer passengerID);
    
    
   public abstract int removePassengerSeat(Integer passengerID);
      
    
    }
