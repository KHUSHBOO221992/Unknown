package com.example.macstudent.poll;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnLogin;
    EditText edtUsername;
    EditText edtPassword;

    DBHelper dbHelper;
    SQLiteDatabase PollDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        edtUsername = (EditText) findViewById(R.id.edtUsername);
        edtPassword = (EditText) findViewById(R.id.edtPassword);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnLogin.getId()) {
            String uname = edtUsername.getText().toString();
            String passwd = edtPassword.getText().toString();

            if (uname.equals("test") && passwd.equals("test")) {
                Toast.makeText(this,
                        "Login successful",
                        Toast.LENGTH_LONG).show();

                Intent homeIntent = new Intent
                        (this, HomeActivity.class);
                startActivity(homeIntent);
            }
        }

    }
}
