package com.example.macstudent.poll;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class QuestionActivity extends AppCompatActivity implements View.OnClickListener {

    TextView title,question,findmore1,findmore2,findmore3,findmore4;
    RadioButton rdoOption1,rdoOption2,rdoOption3,rdoOption4;
    Button btnSubmit;
    String pollTitles[] = {"Tim","Technology","Politics"};
    String questions[] = {"What is the best thing about Tim?",
            "Which is the IT hub of Canada?",
            "Who is the most famous prime minister?"};
    String options[][] = {{"Coffee", "Donuts", "Bagels", "Timbits"},
            {"Toronto", "Ottawa", "Montreal", "Vancouver"},
            {"Justine Trudeau","John Abbott", "Kim Campbell", "Charles Tupper"}};
    int countOptions[][] = {{0,0,0,0},{0,0,0,0},{0,0,0,0}};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
        title = (TextView)findViewById(R.id.txt_title);
        question = (TextView)findViewById(R.id.txt_question);
        findmore1 = (TextView)findViewById(R.id.txt_findmore1);
        findmore1.setOnClickListener(this);
        findmore2 = (TextView)findViewById(R.id.txt_findmore2);
        findmore2.setOnClickListener(this);
        findmore3 = (TextView)findViewById(R.id.txt_findmore3);
        findmore3.setOnClickListener(this);
        findmore4 = (TextView)findViewById(R.id.txt_findmore4);
        findmore4.setOnClickListener(this);
        btnSubmit = (Button)findViewById(R.id.btn_submit);
        btnSubmit.setOnClickListener(this);
        rdoOption1 = (RadioButton)findViewById(R.id.rdo_option1);
        rdoOption1.setOnClickListener(this);
        rdoOption2 = (RadioButton)findViewById(R.id.rdo_option2);
        rdoOption2.setOnClickListener(this);
        rdoOption3 = (RadioButton)findViewById(R.id.rdo_option3);
        rdoOption3.setOnClickListener(this);
        rdoOption4 = (RadioButton)findViewById(R.id.rdo_option4);
        rdoOption4.setOnClickListener(this);
        insertData();
        SharedPreferences sp = getSharedPreferences("com.example.macstudent.poll.shared", Context.MODE_PRIVATE);
        //int data = sp.getInt("idtim",0);
        //int data1 = sp.getInt("idtec",0);
        // int data2 = sp.getInt("idpol",0);
        if(sp.getInt("idtim",0) == R.id.nav_tim) {

            title.setText(pollTitles[0]);
            question.setText(questions[0]);
            rdoOption1.setText(options[0][0]);
            rdoOption2.setText(options[0][1]);
            rdoOption3.setText(options[0][2]);
            rdoOption4.setText(options[0][3]);
        }
        if(sp.getInt("idtim",0) == R.id.nav_technology) {

            title.setText(pollTitles[1]);
            question.setText(questions[1]);
            rdoOption1.setText(options[1][0]);
            rdoOption2.setText(options[1][1]);
            rdoOption3.setText(options[1][2]);
            rdoOption4.setText(options[1][3]);
        }
        if( sp.getInt("idtim",0) == R.id.nav_politics) {

            title.setText(pollTitles[2]);
            question.setText(questions[2]);
            rdoOption1.setText(options[2][0]);
            rdoOption2.setText(options[2][1]);
            rdoOption3.setText(options[2][2]);
            rdoOption4.setText(options[2][3]);
        }

    }


    @Override
    public void onClick(View view) {
        String title1 = rdoOption1.getText().toString();
        String title2 = rdoOption2.getText().toString();
        String title3 = rdoOption3.getText().toString();
        String title4 = rdoOption4.getText().toString();
        String find1 = findmore1.getText().toString();
        String find2 = findmore2.getText().toString();
        String find3 = findmore3.getText().toString();
        String find4 = findmore4.getText().toString();
        if(view.getId() == btnSubmit.getId()){
            Toast.makeText(this,"poll submitted",Toast.LENGTH_LONG).show();
        }
        if(view.getId() == findmore1.getId()) {

            SharedPreferences sp = getSharedPreferences("com.example.macstudent.poll.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("option",title1);
            edit.commit();


            Intent findIntent = new Intent(getApplicationContext(),SearchActivity.class);
            startActivity(findIntent);


        }
        if(view.getId() == findmore2.getId()) {

            SharedPreferences sp = getSharedPreferences("com.example.macstudent.poll.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("option",title2);
            edit.commit();


            Intent findIntent = new Intent(getApplicationContext(),SearchActivity.class);
            startActivity(findIntent);


        }
        if(view.getId() == findmore3.getId()) {

            SharedPreferences sp = getSharedPreferences("com.example.macstudent.poll.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("option",title3);
            edit.commit();


            Intent findIntent = new Intent(getApplicationContext(),SearchActivity.class);
            startActivity(findIntent);


        }
        if(view.getId() == findmore4.getId()) {

            SharedPreferences sp = getSharedPreferences("com.example.macstudent.poll.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("option",title4);
            edit.commit();


            Intent findIntent = new Intent(getApplicationContext(),SearchActivity.class);
            startActivity(findIntent);


        }


    }

    public void insertData(){
        DBHelper dbHelper = new DBHelper(getApplicationContext());
        SQLiteDatabase pollDB = dbHelper.getWritableDatabase();



        for(int i=0; i<pollTitles.length; i++) {

            ContentValues cv = new ContentValues();
            cv.put("PollTitle", pollTitles[i]);
            cv.put("Question", questions[i]);

            for(int j=0;j<4;j++) {
                cv.put("Option"+(j+1), options[i][j]);
                cv.put("CountOption"+(j+1), countOptions[i][j]);
            }

            try {
                pollDB = dbHelper.getWritableDatabase();
                pollDB.insert("Poll",null, cv);
                Log.v("Insert record", "Record inserted successfully");
            } catch (Exception e) {
                Log.e("Insert Record Error", e.getMessage());
            }
        }
        pollDB.close();
    }
}
