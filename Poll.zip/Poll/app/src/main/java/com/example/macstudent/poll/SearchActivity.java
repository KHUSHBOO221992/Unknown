package com.example.macstudent.poll;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class SearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        WebView webManual = (WebView) findViewById(R.id.webManual);
        SharedPreferences sp = getSharedPreferences("com.example.macstudent.poll.shared", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sp.edit();
        webManual.loadUrl("http:///www.google.com/search");
    }
}
