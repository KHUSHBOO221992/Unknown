package com.example.macstudent.poll;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FeedbackActivity extends AppCompatActivity implements View.OnClickListener
{

    Button btnEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        btnEmail = (Button) findViewById(R.id.btnEmail);
        btnEmail.setOnClickListener(this);
    }

    @Override
    public void onClick(View view)

        {
            Intent emailIntent = new Intent(Intent.ACTION_SEND);
            emailIntent.setType("text/plain");

            emailIntent.putExtra(Intent.EXTRA_EMAIL,
                    new String[]{"jigisha.patel@cestarcollege.com"});

            emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                    "Test Email");
            emailIntent.putExtra(Intent.EXTRA_TEXT,
                    "This is a test message");

            emailIntent.setType("message/rfc822");

            startActivity(Intent.createChooser(emailIntent,
                    "Select Email Client"));
        }

}
