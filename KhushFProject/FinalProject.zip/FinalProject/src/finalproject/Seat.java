package finalproject;

public class Seat 
{
   int Number;
}
